<?php

use App\Http\Controllers\TestController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('contacts','ContactForms');
//restのconrtollerで処理する物なので@~はいらない。Rest側で用意されてあるため

Route::get('tests/test','TestController@index');

Route::get('contact/index','ContactForms@index')->name('contact.index');
     //->name('viewディレクトリーとファイル名');を書くと後々楽になる、フォームとかでリンク先、送信先の指定ができるため
     //{{route(contact.index)}}といったように
Route::get('contact/create','ContactForms@create')->name('contact.create');

Route::post('contact/store','ContactForms@store')->name('contact.store');

Route::get('contact/show/{id}','ContactForms@show')->name('contact.show');
            // 検索する際はこのように/番号を付けなければならないcontact/show/１
Route::get('contact/edit/{id}','ContactForms@edit')->name('contact.edit');
            //editは登録履歴の表示だけなのでgetで大丈夫
Route::post('contact/update/{id}','ContactForms@update')->name('contact.update');

Route::post('contact/destroy/{id}','ContactForms@destroy')->name('contact.destroy');




// Route::get('contact/index','ContactFormController');
//lessons/lessonを検索するとControllerのLessonControllerファイルに処理が渡される。
//LessonControllerファイルには上記の@のあとの名前の関数を作る

//ここからnomartusk
Route::get('nomarl/index','NomartuskController@index')->name('nomarl.index');
Route::get('nomarl/create','NomartuskController@create')->name('nomarl.create');
Route::post('nomarl/store','NomartuskController@store')->name('nomarl.store');
Route::get('nomarl/show/{id}','NomartuskController@show')->name('nomarl.show');
Route::get('nomarl/edit/{id}','NomartuskController@edit')->name('nomarl.edit');
Route::post('nomarl/update/{id}','NomartuskController@update')->name('nomarl.update');
Route::post('nomarl/destroy/{id}','NomartuskController@destroy')->name('nomarl.destroy');

//ここからmay
Route::group(['prefix'=>'may','middleware'=>'auth'], function (){
Route::get('index','MayController@index')->name('may/index');
Route::get('create','MayController@create')->name('may/create');
Route::post('store','MayController@store')->name('may/store');
Route::get('show/{id}','MayController@show')->name('may/show');
Route::get('edit/{id}','MayController@edit')->name('may/edit');
Route::post('update/{id}','MayController@update')->name('may/update');
Route::post('destroy/{id}','MayController@destroy')->name('may/destroy');
Route::post('post','MayController@post');

});
Auth::routes();
